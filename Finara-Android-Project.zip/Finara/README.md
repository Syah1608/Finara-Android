# Finara — Personal Finance (Android)

Starter project for a native Android offline personal finance app.

## Included in this starter
- Native Android project (Kotlin + Jetpack Compose)
- Offline local storage via Room database
- Dashboard with balance, income, expense totals
- Add income/expense transactions
- Basic budget tracking and savings goals data models
- PIN preference scaffolding and backup/export direction
- Indonesian Rupiah formatting

## Build an APK
1. Install Android Studio (stable) and Android SDK.
2. Open this folder as a project.
3. Let Gradle sync.
4. Build > Build APK(s).
5. For a signed release APK: Build > Generate Signed Bundle / APK.

The project requires internet on first build to download Gradle dependencies. The resulting app's transaction storage is local and works offline.

## Important
This is a functional starter, not yet a fully verified production financial app. PIN protection, CSV/JSON export-import, recurring transaction automation, debt tracking, advanced charts, and thorough tests are planned next-stage features. Do not rely on it as the only copy of important financial records until backup/import has been implemented and tested.
