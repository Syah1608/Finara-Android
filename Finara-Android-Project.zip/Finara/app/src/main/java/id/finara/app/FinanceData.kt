package id.finara.app

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "transactions")
data class FinanceTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Long,
    val type: String, // INCOME or EXPENSE
    val category: String,
    val account: String = "Tunai",
    val note: String = "",
    val dateMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets", primaryKeys = ["category", "monthKey"])
data class Budget(val category: String, val monthKey: String, val limitAmount: Long)

@Entity(tableName = "savings_goals")
data class SavingsGoal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val targetAmount: Long,
    val savedAmount: Long = 0,
    val targetDateMillis: Long? = null
)

@Dao
interface FinanceDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC, id DESC")
    fun observeTransactions(): Flow<List<FinanceTransaction>>

    @Insert suspend fun insertTransaction(transaction: FinanceTransaction): Long
    @Update suspend fun updateTransaction(transaction: FinanceTransaction)
    @Delete suspend fun deleteTransaction(transaction: FinanceTransaction)

    @Query("SELECT * FROM budgets ORDER BY category")
    fun observeBudgets(): Flow<List<Budget>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertBudget(budget: Budget)

    @Query("SELECT * FROM savings_goals ORDER BY id DESC")
    fun observeGoals(): Flow<List<SavingsGoal>>
    @Insert suspend fun insertGoal(goal: SavingsGoal)
    @Update suspend fun updateGoal(goal: SavingsGoal)
    @Delete suspend fun deleteGoal(goal: SavingsGoal)
}

@Database(entities = [FinanceTransaction::class, Budget::class, SavingsGoal::class], version = 1, exportSchema = false)
abstract class FinanceDatabase : RoomDatabase() {
    abstract fun financeDao(): FinanceDao
}
