package id.finara.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private val Navy = Color(0xFF142D4E)
private val Green = Color(0xFF16866B)
private val Red = Color(0xFFD94F55)
private val CanvasBg = Color(0xFFF4F6F9)
private val Muted = Color(0xFF778397)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, FinanceDatabase::class.java, "finara.db").build()
        setContent { FinaraApp(db.financeDao()) }
    }
}

private fun rupiah(value: Long): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
    maximumFractionDigits = 0
}.format(value)

private fun dateText(millis: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date(millis))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinaraApp(dao: FinanceDao) {
    val scope = rememberCoroutineScope()
    val transactions by dao.observeTransactions().collectAsState(initial = emptyList())
    var page by remember { mutableStateOf("Beranda") }
    var showAdd by remember { mutableStateOf(false) }
    var showBudget by remember { mutableStateOf(false) }
    var showGoal by remember { mutableStateOf(false) }

    val income = transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val expense = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val balance = income - expense
    val monthKey = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    val monthTransactions = transactions.filter {
        SimpleDateFormat("yyyy-MM", Locale.US).format(Date(it.dateMillis)) == monthKey
    }
    val monthIncome = monthTransactions.filter { it.type == "INCOME" }.sumOf { it.amount }
    val monthExpense = monthTransactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Green, background = CanvasBg, surface = Color.White)) {
        Scaffold(
            containerColor = CanvasBg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Finara", fontWeight = FontWeight.Bold, color = Navy, fontSize = 23.sp)
                            Text("Keuangan lebih terarah", fontSize = 12.sp, color = Muted)
                        }
                    },
                    actions = { IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.AddCircle, "Tambah transaksi", tint = Green) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = CanvasBg)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Beranda" to Icons.Default.Home, "Transaksi" to Icons.Default.ReceiptLong,
                        "Anggaran" to Icons.Default.PieChart, "Target" to Icons.Default.Savings,
                        "Lainnya" to Icons.Default.Settings).forEach { (label, icon) ->
                        NavigationBarItem(selected = page == label, onClick = { page = label },
                            icon = { Icon(icon, contentDescription = label) }, label = { Text(label, fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            when (page) {
                "Beranda" -> Dashboard(Modifier.padding(padding), balance, monthIncome, monthExpense, transactions, onAdd = { showAdd = true })
                "Transaksi" -> TransactionList(Modifier.padding(padding), transactions, onDelete = { scope.launch { dao.deleteTransaction(it) } })
                "Anggaran" -> BudgetScreen(Modifier.padding(padding), dao, monthExpense, showAdd = { showBudget = true })
                "Target" -> GoalsScreen(Modifier.padding(padding), dao, showAdd = { showGoal = true })
                else -> SettingsScreen(Modifier.padding(padding))
            }
        }
        if (showAdd) AddTransactionDialog(onDismiss = { showAdd = false }, onSave = { tx ->
            scope.launch { dao.insertTransaction(tx) }
            showAdd = false
        })
        if (showBudget) AddBudgetDialog(onDismiss = { showBudget = false }, onSave = { budget ->
            scope.launch { dao.upsertBudget(budget) }
            showBudget = false
        })
        if (showGoal) AddGoalDialog(onDismiss = { showGoal = false }, onSave = { goal ->
            scope.launch { dao.insertGoal(goal) }
            showGoal = false
        })
    }
}

@Composable
private fun Dashboard(
    modifier: Modifier, balance: Long, income: Long, expense: Long,
    transactions: List<FinanceTransaction>, onAdd: () -> Unit
) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("TOTAL SALDO TERCATAT", color = Color(0xFFCFD9E7), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(rupiah(balance), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowDownward, null, tint = Color(0xFF6BE0B5), modifier = Modifier.size(16.dp)); Text(" Pemasukan", color = Color(0xFFCFD9E7), fontSize = 12.sp) }
                            Text(rupiah(income), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ArrowUpward, null, tint = Color(0xFFFFA6A6), modifier = Modifier.size(16.dp)); Text(" Pengeluaran", color = Color(0xFFCFD9E7), fontSize = 12.sp) }
                            Text(rupiah(expense), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                QuickAction("Pemasukan", Icons.Default.Add, Green, Modifier.weight(1f)) { onAdd() }
                QuickAction("Pengeluaran", Icons.Default.Remove, Red, Modifier.weight(1f)) { onAdd() }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Ringkasan bulan ini", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Navy)
                    Spacer(Modifier.height(14.dp))
                    SummaryRow("Pemasukan", income, Green)
                    Spacer(Modifier.height(10.dp))
                    SummaryRow("Pengeluaran", expense, Red)
                    Spacer(Modifier.height(14.dp))
                    Text("Arus kas bersih", fontSize = 12.sp, color = Muted)
                    Text(rupiah(income - expense), fontWeight = FontWeight.Bold, color = if (income >= expense) Green else Red, fontSize = 21.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Komposisi pengeluaran", fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp)
                    Spacer(Modifier.height(12.dp))
                    val cats = transactions.filter { it.type == "EXPENSE" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.toList().sortedByDescending { it.second }.take(5)
                    if (cats.isEmpty()) Text("Grafik akan muncul setelah kamu mencatat pengeluaran.", color = Muted, fontSize = 13.sp)
                    else {
                        val total = cats.sumOf { it.second }.coerceAtLeast(1)
                        cats.forEach { (name, amount) ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text(name, Modifier.weight(1f), color = Navy, fontSize = 12.sp)
                                Text("${(amount * 100 / total)}%", color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.width(8.dp))
                                Text(rupiah(amount), color = Navy, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(Modifier.height(5.dp))
                            LinearProgressIndicator(progress = { amount.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(6.dp), color = Green, trackColor = CanvasBg)
                            Spacer(Modifier.height(10.dp))
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Transaksi terbaru", color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Lihat semua", color = Green, fontSize = 12.sp, modifier = Modifier.clickable { })
            }
        }
        items(transactions.take(5), key = { it.id }) { TransactionRow(it, onDelete = {}) }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = tint)
            Spacer(Modifier.width(8.dp))
            Text(label, fontWeight = FontWeight.SemiBold, color = Navy, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SummaryRow(label: String, amount: Long, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(color, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(label, Modifier.weight(1f), color = Muted, fontSize = 13.sp)
        Text(rupiah(amount), color = Navy, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun TransactionRow(tx: FinanceTransaction, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(if (tx.type == "INCOME") Color(0xFFE1F6ED) else Color(0xFFFFE9E9), CircleShape), contentAlignment = Alignment.Center) {
                Icon(if (tx.type == "INCOME") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (tx.type == "INCOME") Green else Red)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tx.title, color = Navy, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text("${tx.category} • ${dateText(tx.dateMillis)}", color = Muted, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${if (tx.type == "INCOME") "+" else "−"}${rupiah(tx.amount)}", color = if (tx.type == "INCOME") Green else Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(tx.account, color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun TransactionList(modifier: Modifier, transactions: List<FinanceTransaction>, onDelete: (FinanceTransaction) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Semua") }
    val filtered = transactions.filter { it.title.contains(query, true) || it.category.contains(query, true) }.filter {
        filter == "Semua" || (filter == "Pemasukan" && it.type == "INCOME") || (filter == "Pengeluaran" && it.type == "EXPENSE")
    }
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Riwayat transaksi", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.padding(top = 12.dp, bottom = 10.dp))
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Cari transaksi atau kategori") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Semua", "Pemasukan", "Pengeluaran").forEach {
                FilterChip(selected = filter == it, onClick = { filter = it }, label = { Text(it) })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(filtered, key = { it.id }) { TransactionRow(it) { onDelete(it) } }
        }
    }
}

@Composable
private fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (FinanceTransaction) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("EXPENSE") }
    var category by remember { mutableStateOf("Makanan") }
    var account by remember { mutableStateOf("Tunai") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val categories = if (type == "INCOME") listOf("Gaji", "Usaha", "Bonus", "Hadiah", "Lainnya") else listOf("Makanan", "Transportasi", "Belanja", "Tagihan", "Hiburan", "Kesehatan", "Pendidikan", "Lainnya")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Tambah transaksi", color = Navy, fontWeight = FontWeight.Bold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = type == "EXPENSE", onClick = { type = "EXPENSE"; category = "Makanan" }, label = { Text("Pengeluaran") })
                FilterChip(selected = type == "INCOME", onClick = { type = "INCOME"; category = "Gaji" }, label = { Text("Pemasukan") })
            }
            OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, singleLine = true)
            OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() } }, label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            Text("Kategori", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                categories.take(3).forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 10.sp) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                categories.drop(3).take(3).forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 10.sp) }) }
            }
            OutlinedTextField(account, { account = it }, label = { Text("Dompet / rekening") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") })
            if (error.isNotBlank()) Text(error, color = Red, fontSize = 12.sp)
        }
    }, confirmButton = {
        Button(onClick = {
            val n = amount.toLongOrNull()
            if (title.isBlank()) error = "Nama transaksi wajib diisi."
            else if (n == null || n <= 0) error = "Nominal harus lebih dari nol."
            else onSave(FinanceTransaction(title = title.trim(), amount = n, type = type, category = category, account = account.trim().ifBlank { "Tunai" }, note = note.trim()))
        }) { Text("Simpan") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
private fun BudgetScreen(modifier: Modifier, dao: FinanceDao, monthExpense: Long, showAdd: () -> Unit) {
    val scope = rememberCoroutineScope()
    val budgets by dao.observeBudgets().collectAsState(initial = emptyList())
    val transactions by dao.observeTransactions().collectAsState(initial = emptyList())
    val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    val thisMonthExpense = transactions.filter { it.type == "EXPENSE" && SimpleDateFormat("yyyy-MM", Locale.US).format(Date(it.dateMillis)) == month }
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Anggaran", color = Navy, fontWeight = FontWeight.Bold, fontSize = 23.sp)
            Button(onClick = showAdd) { Icon(Icons.Default.Add, null); Text("Tambah") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (budgets.isEmpty()) item { Text("Belum ada anggaran. Tambahkan batas bulanan per kategori.", color = Muted) }
            items(budgets, key = { it.category + it.monthKey }) { budget ->
                val spent = thisMonthExpense.filter { it.category == budget.category }.sumOf { it.amount }
                val ratio = (spent.toFloat() / budget.limitAmount.coerceAtLeast(1)).coerceIn(0f, 1f)
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(budget.category, Modifier.weight(1f), color = Navy, fontWeight = FontWeight.Bold)
                            Text("${(spent * 100 / budget.limitAmount.coerceAtLeast(1)).coerceAtMost(999)}%", color = if (spent > budget.limitAmount) Red else Green, fontWeight = FontWeight.Bold)
                        }
                        Text("${rupiah(spent)} dari ${rupiah(budget.limitAmount)}", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth(), color = if (spent > budget.limitAmount) Red else Green)
                        if (spent > budget.limitAmount) Text("Anggaran terlampaui", color = Red, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddBudgetDialog(onDismiss: () -> Unit, onSave: (Budget) -> Unit) {
    var category by remember { mutableStateOf("Makanan") }
    var amount by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Anggaran bulanan") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(category, { category = it }, label = { Text("Kategori") }, singleLine = true)
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Batas anggaran (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            if (error.isNotBlank()) Text(error, color = Red)
        }
    }, confirmButton = { Button(onClick = {
        val n = amount.toLongOrNull()
        if (category.isBlank() || n == null || n <= 0) error = "Isi kategori dan nominal yang valid."
        else onSave(Budget(category.trim(), SimpleDateFormat("yyyy-MM", Locale.US).format(Date()), n))
    }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
private fun GoalsScreen(modifier: Modifier, dao: FinanceDao, showAdd: () -> Unit) {
    val goals by dao.observeGoals().collectAsState(initial = emptyList())
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Target tabungan", color = Navy, fontWeight = FontWeight.Bold, fontSize = 23.sp)
            Button(onClick = showAdd) { Icon(Icons.Default.Add, null); Text("Tambah") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (goals.isEmpty()) item { Text("Buat target pertama, misalnya dana darurat atau perangkat baru.", color = Muted) }
            items(goals, key = { it.id }) { goal ->
                val progress = (goal.savedAmount.toFloat() / goal.targetAmount.coerceAtLeast(1)).coerceIn(0f, 1f)
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(goal.name, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("${rupiah(goal.savedAmount)} / ${rupiah(goal.targetAmount)}", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Green)
                        Text("${(progress * 100).toInt()}% tercapai", color = Green, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun AddGoalDialog(onDismiss: () -> Unit, onSave: (SavingsGoal) -> Unit) {
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Target tabungan") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nama target") }, singleLine = true)
            OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("Target (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(saved, { saved = it.filter(Char::isDigit) }, label = { Text("Sudah terkumpul (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            if (error.isNotBlank()) Text(error, color = Red)
        }
    }, confirmButton = { Button(onClick = {
        val t = target.toLongOrNull()
        val s = saved.toLongOrNull() ?: 0L
        if (name.isBlank() || t == null || t <= 0 || s < 0) error = "Isi nama dan nominal yang valid."
        else onSave(SavingsGoal(name = name.trim(), targetAmount = t, savedAmount = s))
    }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
private fun SettingsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Pengaturan", color = Navy, fontWeight = FontWeight.Bold, fontSize = 23.sp)
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Finara • versi 0.1.0", fontWeight = FontWeight.Bold, color = Navy)
                Text("Data transaksi disimpan di perangkat ini.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(8.dp))
                Text("Pencadangan dan PIN aplikasi akan ditambahkan pada iterasi berikutnya.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}
